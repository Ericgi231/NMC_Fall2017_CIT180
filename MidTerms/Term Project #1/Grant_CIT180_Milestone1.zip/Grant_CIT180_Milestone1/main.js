function myMap() {
    var mapOptions = {
        center: new google.maps.LatLng(32.7502793,-117.0001471),
        zoom: 10,
    }
var map = new google.maps.Map(document.getElementById("map"), mapOptions);
}

